# OpenCode memory-leak fixes — forward-porting guide

Base: **OpenCode v1.14.31** (commit `557734b`).
Pack: 6 patches, apply with `git am *.patch`.

This guide is for forward-porting the pack to a newer upstream tag. It
assumes the reader is going from v1.14.31 to some later vN; not the
other way around.

---

## 0. Shape of the fixes

Every fix in this pack falls into one of three shapes. Recognising the
shape tells you how to resolve a conflict.

- **Missing unsubscribe**: something registers a listener / hook /
  interval and never detaches. Fix: capture the return handle and call
  it in a cleanup hook (`onCleanup` for Solid.js, `Effect.addFinalizer`
  for InstanceState, `process.off` for Node signals).
- **Unbounded container**: a `Map`/`Set`/array grows without policy.
  Fix: add a cap constant and FIFO eviction.
- **Retained data on state transition**: when an object transitions
  to "done" (compacted, subagent finished, pending evicted), its heavy
  payload should be released. Fix: null-out, empty, or remove.

---

## 1. Patch-by-patch intent

### 0001 — TUI event listener cleanup (7 files)

**Why**: `event.on()` and `event.subscribe()` in Solid.js components
return an unsubscribe function. The original code ignored it, so every
component re-mount leaked the subscription.

**Pattern**: for each `event.on(...)` / `event.subscribe(...)`,
capture the return into `const unsub = …` (or an array if multiple in
the same component) and add `onCleanup(() => unsub())` before the
component's return. For the SIGHUP handler in `exit.tsx`, capture the
handler and detach with `onCleanup(() => process.off("SIGHUP", handler))`.
For the leader `setTimeout` in `keybind.tsx`, use
`onCleanup(() => clearTimeout(...))`.

**Drift risk**: Solid.js imports change between minor OpenCode
releases. Don't assume `onCleanup` is already imported; merge it into
the existing `import { ... } from "solid-js"` line, don't add a
second import.

### 0002 — LSP diagnostics and open-files caps (2 files)

**Why**: `lsp/client.ts` holds two diagnostic maps (`pushDiagnostics`,
`pullDiagnostics`) plus a `Record<filePath, number>` of open file
versions. None had a cap. `lsp/lsp.ts`'s InstanceState also held
`clients`, `broken`, and `spawning` containers that were never emptied
on dispose.

**Pattern**: FIFO eviction with a single ordered array
(`diagnosticOrder`) shared between both diagnostic maps. Caps: 200
for diagnostic files, 1000 for open files.

**Core invariant**: a filePath appears in `diagnosticOrder` if and
only if it appears in `pushDiagnostics` OR `pullDiagnostics`. Every
site that touches either map must maintain this invariant.

**Three call sites need the cap**:

1. `updatePushDiagnostics`: on empty `next`, delete from push and
   remove from order only if not in pull. On non-empty, check if
   filePath is in **either** map before deciding whether to append
   to order. Apply cap and evict from both maps if exceeded.
2. `updatePullDiagnostics`: symmetric. Does NOT emit `Bus.publish`
   (only push does — intentional, preserves upstream wire behaviour).
3. Seed branch (TypeScript-only, inside the `publishDiagnostics`
   handler): inserts directly without going through
   `updatePushDiagnostics`. Must still apply the cap inline, or
   projects with many TypeScript files bypass backpressure.

`notify.open` must also remove the file from both maps and from order.
`shutdown` must clear both maps and reset the order.

**Drift risk**: if upstream unifies push/pull back into a single map,
collapse the two update functions. If a third diagnostic channel
appears, extend the invariant to N maps. To locate the maps after a
rename, grep `new Map<string, Diagnostic`.

### 0003 — ACP session and agent disposal (2 files)

**Why**: each subagent creates an `ACPSessionState` in
`ACPSessionManager.sessions` and a pending promise in
`Agent.permissionQueues`. Neither was ever removed.

**Pattern**: add `delete(sessionId)` and `clear()` to
`ACPSessionManager`. Add `closeSession(sessionID)` and `dispose()` to
`Agent`. `closeSession` removes from the session manager and deletes
the per-session entry in `permissionQueues`. `dispose` aborts the
event controller, clears the session manager, clears
`permissionQueues`, and **also** clears `bashSnapshots` and
`toolStarts` as a safety net (those are keyed by `callID`, not
`sessionID`, so they belong only in `dispose`, not in `closeSession`).

**Drift risk**: if new per-session Maps are added to `Agent` (keyed
by `sessionID`), add them to both `closeSession` and `dispose`. If
new per-call Maps are added (keyed by `callID`), add them only to
`dispose`. Grep for `new Map<` or `new Set<` inside the Agent class
and inspect the keys at each call site before deciding.

### 0004 — Compaction, serve/exit, share-next (4 files)

**compaction.ts**: when a message part is marked `compacted`, zero
out `part.state.output` (potentially large string) and set
`part.state.attachments = undefined`. Before this fix the metadata
was set but the payload was never freed.

**serve.ts**: replace the unreachable `await new Promise(() => {})`
with SIGTERM/SIGINT listeners. Before `server.stop()`, call
`Instance.disposeAll()` with a 5-second timeout race. Use a lazy
import for `Instance` to avoid a circular dependency.

**index.ts** (entry point): in the `finally` block, do the same
`Instance.disposeAll()` race. Replace `process.exit()` with
`process.exit(process.exitCode ?? 0)` to preserve error state from
the catch.

**share-next.ts** (the invasive one): original code used
`bus.subscribe(def).pipe(Stream.runForEach(...), Effect.forkScoped)`.
The forked fibers are interrupted on scope close but the underlying
Bus subscription wasn't released, so re-init leaked subscribers.
Rewrite to `bus.subscribeCallback`, which returns an unsub function.
Collect these in `State.unsubs: (() => void)[]`. Add a `dispose()`
method that walks `unsubs`, empties `queue` and `shared`, closes
the scope, and recreates it. Call `dispose()` at the start of
`init()` for safe re-initialization.

Two details:

1. `yield* dispose()` needs **parentheses**. `Effect.fn(...)(function*
   {...})` returns a function, not an Effect. `yield*` requires an
   iterable; a function isn't iterable. Same rule applies to every
   `Effect.fn`-declared value in the codebase: they're functions,
   call them.
2. The `Interface` declares `dispose: () => Effect.Effect<void, never>`.
   The implementation could fail, so a naïve version would have error
   type `unknown`. Wrap in `Effect.catch(() => Effect.sync(() =>
   log.error(...)))` to produce a genuinely-never Effect. Don't use
   `as () => Effect<void, never>` — that lies to callers.

**Drift risk**: if Bus `Interface` changes `subscribeCallback` or its
return shape, re-check. New event types subscribed upstream need
matching `watch(...)` calls in `init()`. If `InstanceState.make`
signature changes, adjust the `Effect.fn("ShareNext.state")` wrapper.

### 0005 — Subprocess, RPC, and timer cleanup (5 files)

**provider/models.ts**: capture the `setInterval` handle, call
`.unref()`, register `process.on("exit", () => clearInterval(handle))`.

**pty/index.ts**: in `teardown(session)`, add `session.buffer = ""`.

**mcp/index.ts**: five `pendingOAuthTransports` sites (two `set`,
two `delete`, one `clear` inside the InstanceState finalizer).
Before each `set`/`delete`, capture the existing entry and call
`.close?.().catch(() => {})`. Before the `clear()` in the finalizer,
iterate `pendingOAuthTransports.values()` and close each transport.

> Two of the four `set`/`delete` sites have a local `transport`
> already in scope. Name the captured value `existingTransport` or
> similar to avoid TS2451 (block-scoped redeclaration).

> The `clear()` site matters because OAuth-pending transports outlive
> normal client disposal: when `Config.invalidate` triggers
> `Instance.disposeAll()` mid-process, the finalizer runs and a bare
> `clear()` would drop transport references whose HTTP/SSE
> connections never close. Same "close before evict" invariant as
> the four set/delete sites.

**shell/shell.ts**: add an `alive()` helper that returns `false` if
the exit callback reports the process is gone OR if
`process.kill(-pid, 0)` throws (signal 0 is a pure existence check).
Use `alive()` before `SIGKILL` in the try-branch only. The catch-branch
keeps `opts?.exited?.()` as the only reliable probe after the group
signal failed.

**util/rpc.ts**: cap `pending` Map at 10,000 entries. On overflow,
evict the oldest and **reject** its promise with
`RPC evicted: pending limit (10000) exceeded`. Silently dropping
would hang the caller forever.

Additionally, wrap `target.postMessage(JSON.stringify(...))` in
try/catch. If `JSON.stringify` throws (circular refs, BigInt),
delete the just-added `pending` entry and reject with the original
error. Without this, the orphan entry sits in the Map until cap
eviction spuriously rejects some other caller's live promise.

**Drift risk**: if the RPC client is refactored to AbortController,
integrate rejection there. Invariants to preserve: (a) no caller
ever hangs on an evicted request; (b) no entry added to `pending`
without a reachable path that will resolve or reject it.

### 0006 — SDK event queue cap and subagent session cleanup (2 files)

**sdk.tsx**: the SDK event queue buffers events between the SDK
stream and the Solid `batch()` flush. If the UI falls behind, it
grows indefinitely. Cap at 1000; on overflow, drop the oldest.

**tool/task.ts** (highest-impact fix for heavy subagent users): when
`task_id` resolves to an existing session, it's a resume and must be
preserved. Otherwise the tool created a fresh session that should be
released. Inside the `acquireUseRelease` use-phase, after
`ops.prompt(...)` returns, if the local `session` variable (the
result of attempting to load from `task_id`) is falsy, call
`sessions.remove(nextSession.id)`. Wrap in
`Effect.catchCause(() => Effect.void)` so cleanup failures don't
fail the tool result.

The condition is `!session`, not `!taskID`. See §3 for why.

**Drift risk**: if the task tool gains a non-ephemeral mode (cached
sessions beyond `task_id` resume), widen the condition. Intent is
"release any session we created purely for this one-shot invocation".

---

## 2. Applying to a newer release

```bash
git clone https://github.com/anomalyco/opencode.git
cd opencode
git checkout <target-tag>
git am /path/to/*.patch
```

If all six apply, typecheck and build (§4).

If `git am` stops with a conflict, resolve per-patch:

**0001 TUI**: the Solid.js import line is the most common conflict
point. Add `onCleanup` manually, `git am --continue`. If a component
was split, replicate the pattern: grep for un-captured
`event.on/subscribe` and wrap each.

**0002 LSP**: preserve the invariant "filePath in `diagnosticOrder`
iff in any diagnostic map". Three sites need the cap: the two
update functions and the seed branch. Missing `updatePullDiagnostics`
leaks pull-based diagnostics silently. Grep `new Map<string,
Diagnostic` to locate renamed maps.

**0003 ACP**: grep `new Map<string,` inside the Agent class for new
per-session Maps; add them to `closeSession` and `dispose`.

**0004 share-next**: the riskiest conflict. Effect version upgrades
can shift `Stream.runForEach` / `Effect.forkScoped` /
`subscribeCallback` signatures. Invariants: (a) State carries
`unsubs: (() => void)[]`, (b) `init()` calls `dispose()` before
subscribing, (c) `dispose()` is the canonical cleanup. Preserve
those; don't stress the Effect mechanics.

**0005 rpc/subprocess**: if `pending` shape changes, update the
struct but keep cap + reject-on-evict, and keep the try/catch around
`postMessage(JSON.stringify(...))`. For `mcp/index.ts`, follow rule
4 in §3 — every new `pendingOAuthTransports` site upstream must
either close before mutate (set/delete) or iterate and close before
clear (the finalizer site).

**0006 task**: if the session lifecycle around `acquireUseRelease`
changes, move `sessions.remove(...)` to wherever "subagent finished
and its session is no longer needed" lives. Keep it **inside** the
use phase, not release, so cleanup errors don't mask tool result
errors.

---

## 3. Adaptation rules

These rules survive any version of the base. Read them before
editing a patch.

1. **`!session` vs `!taskID`** (patch 0006). `session` is the local
   bound to `sessions.get(taskID) ?? undefined`. An invalid taskID
   passes `!taskID` (truthy string) but still forces
   `sessions.create(...)` via the `??` fallback, which would leak.
   `!session` captures the real invariant: "we created a new
   session this invocation; release it". Do not switch to `!taskID`
   even if the surrounding code changes.

2. **Cleanup failures must be silent.** Every cleanup (`dispose`,
   transport close, session remove, etc.) wraps its body in
   `Effect.catchCause(() => Effect.void)` or equivalent. Failing
   cleanup must not mask the primary failure or fail the user's
   request. Don't "improve" this by propagating errors.

3. **Don't add observable behaviour as a side effect of a fix.** A
   leak fix should change RSS over time, not the wire format. Concrete
   case: when `updatePullDiagnostics` was added in 0002, it would
   have been "natural" to make it emit `Bus.publish` like
   `updatePushDiagnostics`. Don't. Upstream had a reason for the
   asymmetric emission; preserve it.

4. **Scan every use of a guarded map when porting.** The pack
   guards several maps (`pendingOAuthTransports`, the diagnostic
   maps, `permissionQueues`, `pending` in rpc, etc.) with a
   "close-before-evict" or "delete-before-overwrite" invariant.
   Upstream may add new operations to those maps in later versions.
   A naïve port only touches the call sites the original patch
   covered and silently leaves new sites uncovered. Mechanical
   procedure when applying to a newer base:

   a. List every Map / Set the pack guards (the sets, deletes, and
      clears it modifies).
   b. For each one, grep `<map>\.\(set\|delete\|clear\)` in the
      target base.
   c. New occurrences relative to v1.14.31 are candidate sites.
   d. Inspect each: if it overwrites or removes entries that hold
      owned resources (transports, timers, child processes, file
      descriptors, large strings), it needs the same cleanup the
      pack applies elsewhere. If it only resets a counter, index,
      or offset, it doesn't.

5. **Use `process.exit(process.exitCode ?? 0)` not `process.exit()`**.
   Bare `process.exit()` returns 0 even after errors set
   `process.exitCode` in catch blocks. Only matters in 0004's
   `index.ts`, but easy to lose on refactors.

---

## 4. Verification

### 4.1 Apply cleanly

```bash
git am /path/to/*.patch
```

All six must apply before proceeding.

### 4.2 Typecheck

```bash
bun install --linker hoisted --ignore-scripts
cd packages/opencode
bunx tsgo --noEmit
```

Required: exit 0. A passing typecheck is necessary; not sufficient.

If `bun install` fails on unrelated workspace deps, reduce the
workspace list to only what opencode needs:

```bash
python3 -c "
import json
with open('package.json') as f: pkg = json.load(f)
pkg['workspaces']['packages'] = [
    'packages/opencode', 'packages/plugin', 'packages/script',
    'packages/shared', 'packages/sdk/js',
]
with open('package.json', 'w') as f: json.dump(pkg, f, indent=2)
"
```

Restore with `git checkout package.json` after typecheck.

### 4.3 Verify pinned API surface

When a patch uses a function from a pinned dependency (the pack uses
several from `effect`), confirm the function is actually exported in
the pinned version — JSDoc mentions don't count, only exports do:

```bash
grep '"effect"' bun.lock | head -1
npm pack effect@<pinned-version>
tar xzf effect-<pinned-version>.tgz
grep -n "export.*<function-name>" package/dist/*.d.ts
```

### 4.4 Smoke test

Build (§5), then exercise each fix against a real workload:

- Navigate between TUI sessions repeatedly. RSS should stabilise.
  (0001)
- Open and close many files in an LSP-heavy project. RSS should
  stabilise. (0002)
- Launch several subagents, let them finish, trigger another
  operation. RSS should stabilise — this is the highest-impact
  check because 0006 is the highest-impact fix. (0006)
- If `share` is enabled, let `init()` run at least once. (0004)

---

## 5. Build

Use `build.sh`. If building by hand:

```bash
bun install --linker hoisted --ignore-scripts
cd packages/opencode
env OPENCODE_VERSION="<target-tag>-fix" bun run script/build.ts \
  --single --skip-embed-web-ui --skip-install
```

Constraints (these are non-obvious; do not "simplify" them):

- **bun >= 1.3.13** required. Bun 1.3.12 has a bundler regression
  on `throw new Error(...)`. `build.sh` enforces this.
- **`--linker hoisted`** required. `drizzle-orm`'s subpath exports
  don't resolve from Bun's default `.bun/` layout.
- **`external` in `build.ts` must stay at `["node-gyp"]` only**.
  Adding `drizzle-orm` or `drizzle-orm/*` breaks runtime resolution.
- **`--skip-install` required with `--single`**. Without it,
  `build.ts` runs two internal installs that disrupt the hoisted
  layout.

Binary output:
`packages/opencode/dist/opencode-<platform>/bin/opencode`.
