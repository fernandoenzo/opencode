#!/usr/bin/env bash
#
# build.sh — Build an opencode standalone binary from an already-prepared tree.
#
# This script does NOT apply patches. It assumes you (or an LLM following
# FORWARD-PORTING-GUIDE.md) have already produced a working tree with the
# memory-leak fixes applied and typechecking cleanly. Its only job is to
# turn that tree into an executable binary.
#
# The reason for this split: applying patches safely across versions is a
# reasoning task (resolve drift, adapt imports, verify APIs against pinned
# deps). Running the build on an already-correct tree is a mechanical task.
# Automating the first would hide errors; automating the second saves time.
#
# Usage:
#   # Default: current directory must be the root of a patched opencode clone
#   ./build.sh
#
#   # Or point it somewhere else:
#   ./build.sh --source /path/to/patched/opencode
#
#   # Destination for the built binary:
#   ./build.sh --out /path/to/opencode-patched
#
#   # Install over your current opencode on PATH (prompts sudo if needed):
#   ./build.sh --install
#
#   # Skip typecheck (NOT recommended - see FORWARD-PORTING-GUIDE.md section 7):
#   ./build.sh --no-typecheck
#
#   # Combine freely:
#   ./build.sh --source ~/src/opencode --install
#
# Requirements:
#   - bash 4+, git (only for status info), bun on PATH (install with
#     `npm i -g bun` if missing)
#   - ~2 GB free disk for node_modules
#   - Network access to npm registry (and nodejs.org for tree-sitter native
#     addon headers during the build)
#
# Target platform: autodetected. For Linux x86_64 this produces
# `dist/opencode-linux-x64/bin/opencode`.
#
# Exit codes:
#   0   success
#   2   precondition (missing tool, wrong cwd, bad flag)
#   4   typecheck failed (refusing to build broken code)
#   5   build failed
#   6   smoke test failed
#
set -euo pipefail

# ─── argument parsing ─────────────────────────────────────────────────────────
SOURCE_DIR="$(pwd)"
OUT_PATH=""
INSTALL=0
SKIP_TYPECHECK=0

while [ $# -gt 0 ]; do
  case "$1" in
    --source)        SOURCE_DIR="$2"; shift 2 ;;
    --source=*)      SOURCE_DIR="${1#*=}"; shift ;;
    --out)           OUT_PATH="$2"; shift 2 ;;
    --out=*)         OUT_PATH="${1#*=}"; shift ;;
    --install)       INSTALL=1; shift ;;
    --no-typecheck)  SKIP_TYPECHECK=1; shift ;;
    -h|--help)
      sed -n '2,50p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *) printf "unknown argument: %s (try --help)\n" "$1" >&2; exit 2 ;;
  esac
done

# ─── colours ──────────────────────────────────────────────────────────────────
if [ -t 1 ]; then
  C_OK="$(printf '\033[32m')"
  C_WARN="$(printf '\033[33m')"
  C_ERR="$(printf '\033[31m')"
  C_DIM="$(printf '\033[2m')"
  C_RST="$(printf '\033[0m')"
else
  C_OK="" C_WARN="" C_ERR="" C_DIM="" C_RST=""
fi
say()  { printf "%s==>%s %s\n" "$C_OK" "$C_RST" "$*"; }
warn() { printf "%swarn:%s %s\n" "$C_WARN" "$C_RST" "$*" >&2; }
die()  { printf "%serror:%s %s\n" "$C_ERR" "$C_RST" "$*" >&2; exit "${2:-1}"; }

# ─── resolve source and validate it's an opencode checkout ────────────────────
SOURCE_DIR="$(cd "${SOURCE_DIR}" && pwd)" || die "source directory does not exist" 2
cd "${SOURCE_DIR}"

[ -f "package.json" ] || die "not an opencode checkout (no package.json): ${SOURCE_DIR}" 2
[ -d "packages/opencode" ] || die "not an opencode monorepo (no packages/opencode/): ${SOURCE_DIR}" 2
[ -f "packages/opencode/script/build.ts" ] || die "build script missing - is this really opencode?" 2
say "source: ${SOURCE_DIR}"

# ─── detect platform ──────────────────────────────────────────────────────────
UNAME_S="$(uname -s)"
UNAME_M="$(uname -m)"
case "${UNAME_S}-${UNAME_M}" in
  Linux-x86_64)   PLATFORM="linux-x64" ;;
  Linux-aarch64)  PLATFORM="linux-arm64" ;;
  Darwin-arm64)   PLATFORM="darwin-arm64" ;;
  Darwin-x86_64)  PLATFORM="darwin-x64" ;;
  *) die "unsupported platform: ${UNAME_S}-${UNAME_M}" 2 ;;
esac
say "platform: ${PLATFORM}"

# ─── require bun ──────────────────────────────────────────────────────────────
if ! command -v bun >/dev/null 2>&1; then
  die "bun not on PATH. Install with: npm install -g bun" 2
fi
BUN_VERSION="$(bun --version 2>/dev/null | tr -d '[:space:]')"
say "bun ${BUN_VERSION}"

# Bun 1.3.12 had a bundler regression that failed to compile `throw new
# Error(...)` in certain contexts. Fixed in 1.3.13. Enforce the floor.
MIN_BUN="1.3.13"
if [ -n "${BUN_VERSION}" ]; then
  LOWEST="$(printf '%s\n%s\n' "${MIN_BUN}" "${BUN_VERSION}" | sort -V | head -n1)"
  if [ "${LOWEST}" != "${MIN_BUN}" ]; then
    die "bun ${BUN_VERSION} is too old. Required: >= ${MIN_BUN} (older bun has a bundler regression on 'throw new Error(...)'). Upgrade with: bun upgrade" 2
  fi
fi

# ─── report what we're building (info only, no validation) ────────────────────
if git -C "${SOURCE_DIR}" rev-parse --git-dir >/dev/null 2>&1; then
  BASE_TAG="$(git -C "${SOURCE_DIR}" describe --tags --abbrev=0 2>/dev/null || echo unknown)"
  HEAD_SHA="$(git -C "${SOURCE_DIR}" rev-parse --short HEAD)"
  EXTRA_COMMITS="$(git -C "${SOURCE_DIR}" rev-list "${BASE_TAG}..HEAD" --count 2>/dev/null || echo ?)"
  say "git: ${HEAD_SHA} (${EXTRA_COMMITS} commits ahead of ${BASE_TAG})"
  if [ "${EXTRA_COMMITS}" = "0" ]; then
    warn "no commits ahead of ${BASE_TAG} — this looks like an unpatched tree"
    warn "continuing anyway; ignore if that's intentional"
  fi
fi

# Embed version string: pick up from package.json and append -patched unless
# caller overrode with OPENCODE_VERSION.
if [ -z "${OPENCODE_VERSION:-}" ]; then
  PKG_VERSION="$(bun -e 'console.log(require("./packages/opencode/package.json").version)' 2>/dev/null || echo unknown)"
  OPENCODE_VERSION="${PKG_VERSION}-patched"
fi
say "version string for binary: ${OPENCODE_VERSION}"

# ─── install dependencies ─────────────────────────────────────────────────────
# --linker hoisted: required so drizzle-orm's subpath exports resolve correctly
#                   during Bun.build. Without it the bundler fails to find
#                   drizzle-orm/* modules inside .bun/ structure.
# --ignore-scripts: skip postinstall hooks unrelated to building opencode;
#                   the build runs necessary native-addon compilation itself.
say "installing workspace dependencies"
if ! bun install --linker hoisted --ignore-scripts 2>&1 \
     | tail -10 | sed "s|^|    ${C_DIM}|;s|\$|${C_RST}|"; then
  # Fall back: if node_modules already looks populated from a previous run,
  # the install failure may be about workspaces we don't actually need
  # (private/ghostty-web, pre-release Solid builds behind pkg.pr.new, etc.).
  # Continue if the key deps for opencode are resolvable from the tree.
  if [ -f node_modules/effect/package.json ] \
     && [ -d node_modules/@opencode-ai ]; then
    warn "bun install reported errors but node_modules has the essentials — continuing"
  else
    die "bun install failed and node_modules is not usable. Retry from an unrestricted network, or see FORWARD-PORTING-GUIDE.md for reducing the workspace set." 5
  fi
fi

# ─── typecheck ────────────────────────────────────────────────────────────────
# Gate before build.
if [ "${SKIP_TYPECHECK}" = "1" ]; then
  warn "typecheck skipped (--no-typecheck)"
else
  say "typechecking packages/opencode"
  pushd packages/opencode >/dev/null
  if ! bunx tsgo --noEmit 2>&1 | sed "s|^|    ${C_DIM}|;s|\$|${C_RST}|"; then
    popd >/dev/null
    die "typecheck failed — refusing to build broken code. Fix the errors above, or pass --no-typecheck to bypass (not recommended)." 4
  fi
  popd >/dev/null
  say "typecheck passed"
fi

# ─── build ────────────────────────────────────────────────────────────────────
# --single        : build for the current platform only, not all targets
# --skip-embed-web-ui : skip bundling the web UI (saves time; opencode CLI
#                       works without it)
# --skip-install  : skip build.ts's two internal `bun install` calls for
#                   cross-platform native binaries; not needed for --single.
say "building standalone binary"
pushd packages/opencode >/dev/null
BUILD_LOG="$(mktemp)"
if ! env OPENCODE_VERSION="${OPENCODE_VERSION}" \
       bun run script/build.ts --single --skip-embed-web-ui --skip-install 2>&1 \
     | tee "${BUILD_LOG}" | tail -30 | sed "s|^|    ${C_DIM}|;s|\$|${C_RST}|"; then
  # Common failure mode: native addon (tree-sitter-powershell) can't fetch
  # node headers from nodejs.org. Give the user a clear next step.
  if grep -Eq "nodejs\.org/download.*403|install script from .*tree-sitter" "${BUILD_LOG}"; then
    rm -f "${BUILD_LOG}"
    popd >/dev/null
    die "build failed compiling a native tree-sitter addon. Your network is blocking nodejs.org/download. Try again from an unrestricted network or set a mirror via the NODEJS_ORG_MIRROR env var." 5
  fi
  rm -f "${BUILD_LOG}"
  popd >/dev/null
  die "build failed — see output above" 5
fi
rm -f "${BUILD_LOG}"
popd >/dev/null

BINARY="${SOURCE_DIR}/packages/opencode/dist/opencode-${PLATFORM}/bin/opencode"
[ -x "${BINARY}" ] || die "build finished but binary not found at ${BINARY}" 5

# ─── smoke test ───────────────────────────────────────────────────────────────
say "smoke test: ${BINARY} --version"
if ! "${BINARY}" --version 2>&1 | sed "s|^|    ${C_DIM}|;s|\$|${C_RST}|"; then
  die "binary did not respond to --version" 6
fi

# ─── deliver ──────────────────────────────────────────────────────────────────
if [ -n "${OUT_PATH}" ]; then
  mkdir -p "$(dirname "${OUT_PATH}")"
  cp "${BINARY}" "${OUT_PATH}"
  chmod +x "${OUT_PATH}"
  say "binary copied to ${OUT_PATH}"
fi

if [ "${INSTALL}" = "1" ]; then
  TARGET="$(command -v opencode || true)"
  [ -n "${TARGET}" ] || die "--install: opencode not on PATH, refusing to guess location" 2
  say "installing over ${TARGET}"
  if [ -w "${TARGET}" ]; then
    cp "${BINARY}" "${TARGET}"
  else
    sudo cp "${BINARY}" "${TARGET}"
  fi
  "${TARGET}" --version
  say "installed"
fi

echo
say "done"
echo "binary: ${BINARY}"
echo "version: ${OPENCODE_VERSION}"
if [ -z "${OUT_PATH}" ] && [ "${INSTALL}" = "0" ]; then
  echo
  echo "to install over your current opencode:"
  echo "  sudo cp ${BINARY} \$(which opencode)"
fi
