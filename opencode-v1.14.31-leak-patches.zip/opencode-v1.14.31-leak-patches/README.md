# OpenCode memory-leak patches

Six patches fixing memory leaks that pile up RSS and cause GC thrash
during long sessions, especially with subagent-heavy workloads. Based
on tag `v1.14.31`.

## Apply the patches

```bash
git clone https://github.com/anomalyco/opencode.git
cd opencode
git checkout v1.14.31
git am /path/to/*.patch
```

All six apply cleanly on a fresh `v1.14.31`.

For a different target version or to handle conflicts, read
`FORWARD-PORTING-GUIDE.md`.

## Build the binary

```bash
./build.sh
```

From a different directory:

```bash
./build.sh --source /path/to/patched/opencode
```

The script installs deps, typechecks, builds a single-platform
binary, and smoke-tests it. It fails fast at whichever stage breaks.

### Options

```
./build.sh                           # build from $(pwd)
./build.sh --source DIR              # build from DIR
./build.sh --out /path/to/binary     # also copy the binary there
./build.sh --install                 # overwrite $(which opencode)
./build.sh --no-typecheck            # skip typecheck gate
./build.sh --help                    # full help
```

Exit codes: `0` ok, `2` precondition, `4` typecheck failed,
`5` build failed, `6` smoke test failed.

### Output

```
<source>/packages/opencode/dist/opencode-<platform>/bin/opencode
```

Platform autodetected: `linux-x64`, `linux-arm64`, `darwin-arm64`,
`darwin-x64`.

### Requirements

- `bun >= 1.3.13` on PATH (1.3.12 has a bundler regression that
  breaks the build)
- ~2 GB free disk for `node_modules`
- Network access to the npm registry and `nodejs.org/download/`

## Contents

6 patches + `FORWARD-PORTING-GUIDE.md` + `build.sh`.
22 files modified across 6 commits.
